window.onload = function () {
    'use strict';
    
    /* -----------------------------
      - Sticky Menu
      ------------------------------ */
    var menu = document.getElementById('main-menu'),
        menuTop = menu.offsetTop;
    
    function stickyMenu() {
        if (window.pageYOffset >= menuTop) {
            menu.classList.add('sticky');
        } else {
            menu.classList.remove('sticky');
        }
    }
    
    if (window.innerWidth > 991) {
        window.addEventListener('scroll', stickyMenu);
    }
    
    window.onresize = function () {
        menuTop = menu.offsetTop;
        if (window.innerWidth <= 991) {
            window.removeEventListener('scroll', stickyMenu);
        } else {
            window.addEventListener('scroll', stickyMenu);
        }
    };
    
    /* -----------------------------
      - Search
      ------------------------------ */
    var search = $('.search');
    search.on('click', function (e) {
        if (e.target.nodeName === 'INPUT') 
            return;
        search.toggleClass('open');
    });
    
    /* -----------------------------
      - Mobile menu
      ------------------------------ */
    var mainMenu = $('.main-menu');
    var togMenu = mainMenu.find('.mob-toggle');
    
    togMenu.on('click', function () {
        mainMenu.toggleClass('active');
    });
    
    
    /* -----------------------------
      - Latest News
      ------------------------------ */
    var latesNews = document.getElementById('latest-news');
    var prevNews = latesNews.getElementsByClassName('prev')[0];
    var nextNews = latesNews.getElementsByClassName('next')[0];
    var feedsList = [].slice.call(latesNews.getElementsByClassName('feed'));
    var feedsCount = feedsList.length;
    var i = 0;
    var int;
    
    function newsAnimation(t, cond, val) {
        feedsList[i].classList.add('fadeout');
        feedsList[i].classList.remove('active');
        i += t;
        if (i === +cond) {
            i = +val;
        }
        feedsList[i].classList.remove('fadeout');
        feedsList[i].classList.add('active');
    }
    function newsInterval () {
        int = window.setInterval(function ( ) {
            newsAnimation(1, feedsCount, 0)
        }, 4000);
    }
    newsInterval();
    
    nextNews.addEventListener('click', function () {
        window.clearInterval(int);
        newsAnimation(1, feedsCount, 0);
        newsInterval();
    });
    
    prevNews.addEventListener('click', function () {
        window.clearInterval(int);
        newsAnimation(-1, -1, feedsCount - 1);
        newsInterval();
    });
    
    
    /* -----------------------------
      - Sticky Sidebar
      ------------------------------ */
    if ($('.side-bar')[0]) {

    setTimeout(function () {
        sidebarScrollTop = sidebar.offsetTop;
        sidebarHeight = sidebar.clientHeight;
        footerScrollTop = $('.footer')[0].offsetTop;
    }, 3000);

    var menuHeight = $('#main-menu')[0].clientHeight,
        sidebar = $('.side-bar')[0],
        sidebarScrollTop = sidebar.offsetTop,
        sidebarHeight = sidebar.clientHeight,
        footerScrollTop = $('.footer')[0].offsetTop,
        lastPos = 0,
        is_top,
        windowBottom,
        sidebarBottom;

    function sidebarScroll() {
        is_top = (window.pageYOffset < lastPos) ? true : false;
        windowBottom = window.pageYOffset + window.innerHeight;
        sidebarBottom = sidebar.offsetTop + sidebar.clientHeight;
        if (windowBottom >= sidebarBottom && windowBottom <= footerScrollTop && !is_top) {
            if (window.pageYOffset + window.innerHeight >= $(sidebar).offset().top + sidebarHeight)
                sidebar.style.transform = 'translate3d(0,'+ (window.pageYOffset - sidebarScrollTop - sidebarHeight + window.innerHeight) +'px,0)';
        } else if (window.pageYOffset + menuHeight >= sidebar.offsetTop && windowBottom <= footerScrollTop && is_top) {
            if (window.pageYOffset + menuHeight <= $(sidebar).offset().top)
                sidebar.style.transform = 'translate3d(0,'+ (window.pageYOffset - sidebar.offsetTop + menuHeight) +'px,0)';
        } else if ((window.pageYOffset + sidebarHeight) > footerScrollTop) {
            sidebar.style.transform ='translate3d(0,'+ (footerScrollTop - sidebarHeight - sidebarScrollTop) +'px,0)';
        } else {
            sidebar.style.transform = 'translate3d(0,0,0)';
        }
        lastPos = window.pageYOffset;
    }

    window.addEventListener('scroll', sidebarScroll);

    window.onresize = function () {
        if (window.innerWidth <= 991) {
            window.removeEventListener('scroll', sidebarScroll);
            sidebar.style.transform = 'translate3d(0,0,0)';
        } else {
            menuHeight = $('#main-menu').height();
            sidebarScrollTop = sidebar.offsetTop - menuHeight;
            sidebarHeight = sidebar.clientHeight;
            footerScrollTop = $('.footer')[0].offsetTop;

            window.addEventListener('scroll', sidebarScroll);
        }
    };
}
    
    /* function StickySidebarTop () {
          $(document).ready(function () {
            if ($('.side-bar')[0]) {
              var menuHeight = $('#main-menu').height(),
                  sidebar = $('.side-bar')[0],
                  sidebarScrollTop = sidebar.offsetTop - menuHeight - 10,
                  sidebarHeight = sidebar.clientHeight,
                  footerScrollTop = $('.footer')[0].offsetTop;

              setTimeout(function () {
                sidebarScrollTop = sidebar.offsetTop - menuHeight - 10;
                sidebarHeight = sidebar.clientHeight;
                footerScrollTop = $('.footer')[0].offsetTop;
              }, 4000);

              function sidebarScroll() {
                if (window.pageYOffset >= sidebarScrollTop && (window.pageYOffset + sidebarHeight) <= footerScrollTop) {
                  sidebar.style.transform = 'translate3d(0,'+ (window.pageYOffset - sidebarScrollTop) +'px,0)';
                } else if ((window.pageYOffset + sidebar.clientHeight) > footerScrollTop) {
                  sidebar.style.transform ='translate3d(0,'+ (footerScrollTop - sidebarHeight - sidebarScrollTop) +'px,0)';                  	   		  } else {
                   sidebar.style.transform = 'translate3d(0,0,0)';
                }
              }
              
              
              if (window.innerWidth > 991) {
                sidebar.style.left = sidebar.offsetLeft + 'px';
                window.addEventListener('scroll', sidebarScroll);
              }

              window.onresize = function () {
                if (window.innerWidth <= 991) {
                  window.removeEventListener('scroll', sidebarScroll);
                  sidebar.style.transform = 'translate3d(0,0,0)';
                } else {
                  menuHeight = $('#main-menu').height();
                  sidebarScrollTop = sidebar.offsetTop - menuHeight;
                  sidebarHeight = sidebar.clientHeight;
                  footerScrollTop = $('.footer')[0].offsetTop;
                  window.addEventListener('scroll', sidebarScroll);
                }
              };
            }
          });
    } */
    
        function addFade(elem, fadeClass, animClass) {
            if (elem.getBoundingClientRect().top > window.innerHeight) {
                elem.classList.add(fadeClass);
                elem.classList.add(animClass);	
            }
        }
        // add fadeIntoView with animation 
        if ($('.single-posts')[0]) {
          $.each($('.single-posts .single-post'), function (i, post) {
              addFade($(post)[0], 'fadeIntoView', 'fadeToUp')
          });
        }
        if ($('.home-posts')[0]) {
            $.each($('.big-with-list .big-post, .big-with-list .list-post'), function (i, post) {
                addFade($(post)[0], 'fadeIntoView', 'fadeToUp');
            });
            addFade($('.big-and-list .big-post')[0], 'fadeIntoView', 'fadeToLeft');

            $.each($('.big-and-list .list-post'), function (i, post) {
                addFade($(post)[0], 'fadeIntoView', 'fadeToRight');
            });
        }

        // fade in elemens 
        var fadeElems,
            fELen;

        window.addEventListener('scroll', function () {
            fadeElems = document.getElementsByClassName('fadeIntoView'),
            fELen = fadeElems.length;
          if (fadeElems[0]) {
            while (--fELen > -1) {
              if (fadeElems[fELen].getBoundingClientRect().top + 100 <= window.innerHeight) {
                fadeElems[fELen].classList.add('intoView');
                fadeElems[fELen].classList.remove('fadeIntoView');
              }
            }
          }
        });
    
        /* 
            scroll press: https://github.com/scrollpress/scrollpress
        */
        $(window).scrollPress({
          btn_icon: "<i class='fa fa-angle-up' style='color:#0a8bfb;'/>",
          btn_style: {
            boxShadow: '0 0 1px 1px #0a8bfb'
          },
          btn_clickAnimation_bubble: {
            backgroundColor: '#4988bf'
          },
          btn_clickAnimation_spreadBorder: {
            borderColor: '#4988bf'
          }
        });
};